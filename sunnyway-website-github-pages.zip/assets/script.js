
document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.menu-toggle'), nav=document.querySelector('.nav-links');
 if(toggle&&nav) toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));toggle.textContent=open?'×':'☰';});
 document.querySelectorAll('[data-filter]').forEach(btn=>btn.addEventListener('click',()=>{
   document.querySelectorAll('[data-filter]').forEach(b=>b.classList.remove('active'));btn.classList.add('active');
   const f=btn.dataset.filter;let visible=0;
   document.querySelectorAll('.tour-card').forEach(card=>{const show=f==='all'||card.dataset.category.split(' ').includes(f);card.style.display=show?'flex':'none';if(show)visible++;});
   const empty=document.querySelector('.empty-state');if(empty)empty.style.display=visible?'none':'block';
 }));
 document.querySelectorAll('form[data-inquiry]').forEach(form=>form.addEventListener('submit',e=>{
   e.preventDefault();const d=new FormData(form);
   const text=['Здравствуйте! Хочу подобрать тур через сайт Sunnyway.','Имя: '+(d.get('name')||'не указано'),'Телефон: '+(d.get('phone')||'не указан'),'Направление: '+(d.get('destination')||'помогите выбрать'),'Даты: '+(d.get('dates')||'гибкие'),'Путешественники: '+(d.get('people')||'не указано'),'Комментарий: '+(d.get('message')||'—')].join('\\n');
   const url='https://wa.me/375291036843?text='+encodeURIComponent(text);
   window.open(url,'_blank','noopener');
   const status=form.querySelector('.form-status');if(status)status.textContent='Заявка подготовлена. Если WhatsApp не открылся, позвоните +375 (29) 103-68-43 или напишите на sunnywaytouristik@gmail.com.';
 }));
});
