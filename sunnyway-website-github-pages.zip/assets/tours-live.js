/* Live offers are served by server.js from supplier/aggregator feeds configured by the site owner. */
(() => {
  const root = document.getElementById('live-tours');
  const status = document.getElementById('feed-status');
  const note = document.getElementById('feed-note');
  if (!root) return;

  const esc = (value) => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const fmt = (value, currency) => {
    if (value === undefined || value === null || value === '') return 'Цена по запросу';
    const n = Number(value);
    return Number.isFinite(n) ? new Intl.NumberFormat('ru-RU', {maximumFractionDigits: 0}).format(n) + ' ' + (currency || '') : esc(value);
  };
  const card = (t) => {
    const image = t.image ? ` style="--image:url('${esc(t.image).replace(/'/g, '%27')}')"` : '';
    const date = [t.departureDate, t.nights ? `${t.nights} ночей` : ''].filter(Boolean).join(' · ');
    const meta = [t.departureCity ? `Из ${t.departureCity}` : '', t.meal].filter(Boolean).join(' · ');
    const url = /^https:\/\//i.test(t.url || '') ? t.url : 'https://www.sunnyway.by/minimalnye-tseny';
    return `<article class="hot-card"><a class="hot-photo"${image} href="${esc(url)}" target="_blank" rel="noopener" aria-label="Открыть предложение ${esc(t.hotel || t.destination || 'тура')}">${t.discount ? `<span class="discount">−${esc(t.discount)}%</span>` : ''}</a><div class="hot-info"><div class="stars" aria-label="Предложение туроператора">✦ <span style="color:#718079;font-size:11px;letter-spacing:0">${esc(t.operator || t.source || 'Предложение')}</span></div><h3>${esc(t.hotel || t.title || t.destination || 'Тур')}</h3><p class="place">${esc([t.resort, t.country].filter(Boolean).join(', ') || t.destination || '')}</p><p class="date">${esc(date || 'Даты уточняются')}${meta ? `<br>${esc(meta)}` : ''}</p><div class="price-row">${t.oldPrice ? `<span class="old-price">${fmt(t.oldPrice, t.currency)}</span>` : '<span class="old-price">Актуальная цена</span>'}<strong>${fmt(t.price, t.currency)}</strong></div><p class="live-price-note">Стоимость и наличие проверяются у поставщика.</p><a class="hot-link" href="${esc(url)}" target="_blank" rel="noopener">Открыть предложение ↗</a></div></article>`;
  };

  fetch('/api/tours', {headers:{'Accept':'application/json'}})
    .then(r => { if (!r.ok) throw new Error('feed unavailable'); return r.json(); })
    .then(data => {
      const tours = Array.isArray(data.tours) ? data.tours : [];
      if (!tours.length) throw new Error('no tours');
      root.innerHTML = tours.slice(0, 12).map(card).join('');
      if (status) status.textContent = `Загружено предложений: ${tours.length}${data.updatedAt ? ' · обновлено ' + new Date(data.updatedAt).toLocaleString('ru-RU') : ''}`;
      if (note) note.textContent = 'Данные загружены из настроенных источников. Перед оплатой обязательно перепроверьте актуальную стоимость и наличие мест.';
    })
    .catch(() => {
      root.innerHTML = '<div class="feed-empty"><strong>Лента туров ещё не подключена.</strong><br>Чтобы показывать здесь новые отели и цены автоматически, настройте API/выгрузку Coral Travel, MIROMAX или агрегатора в серверной части. Пока можно открыть текущие предложения на официальном сайте Sunnyway или Coral Travel.</div>';
      if (status) status.textContent = 'Ожидается подключение источника';
    });
})();
